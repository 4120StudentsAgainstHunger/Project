from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from django.contrib.auth import views as auth_views

from . import views


urlpatterns = [
    path('', views.homepage, name='homepage'),
    path('blog', views.blog, name='blog'),
    path('food-pickup', views.foodpickupform, name='food-pickup'),
    path('volunteer-registeration', views.volunteerRegPage, name='volunteer-registeration'),


]

if settings.DEBUG:
    urlpatterns = urlpatterns + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
