from django.shortcuts import render, redirect, HttpResponseRedirect
from django.conf import settings
from django.core.files.storage import FileSystemStorage
from decimal import Decimal as D
from django import forms
from django.views.generic.edit import FormView
#from .form import FileFieldForm
from django.forms import modelformset_factory
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from django.http import HttpResponse
from django.views.generic import ListView, DetailView
from django.views.generic import TemplateView
from django.core.files.storage import FileSystemStorage
from django.shortcuts import render, get_object_or_404
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from .models import *
#from django.core.mmail import send_mail, BadHeaderError
# Create your views here


def homepage(request):
    return render(request, 'homepage.html')


def blog(request):
    return render(request, 'blog.html') 

def foodpickupform(request):
    return render(request, 'foodPickupForm.html')

def volunteerRegPage(request):
    return render(request, 'volunteerRegPage.html')