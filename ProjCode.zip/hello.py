msg = "Hello World"
print(msg)