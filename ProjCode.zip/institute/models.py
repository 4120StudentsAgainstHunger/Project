from django.db import models

class Reservation(models.Model):
    location = models.CharField(max_length=100)
    reservationDate = models.CharField(max_length=100)
    reservationType = models.CharField(max_length=100)
    reservationStartTime = models.CharField(max_length=100)
    reservationEndTime = models.CharField(max_length=100)
