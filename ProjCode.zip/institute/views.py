import sqlite3
from sqlite3 import Error
from django.shortcuts import render

def create_connection(db_file):
    conn = None
    try:
        conn = sqlite3.connect(db_file)
    except Error as e:
        print(e)
    return conn

def home(request):
    database = r"E:\Student Jobs\Django\institute\project\db.sqlite3"
    conn = create_connection(database)
    if request.method == 'POST':
        locationData=request.POST.get("location","")
        reservationDateData=request.POST.get("reservationDate","")
        reservationTypeData=request.POST.get("reservationType","")
        reservationStartTimeData=request.POST.get("reservationStartTime","")
        reservationEndTimeData=request.POST.get("reservationEndTime","")
        sql = ''' INSERT INTO institute_reservation(id,location,reservationDate,reservationType,reservationStartTime,reservationEndTime)
              VALUES(?,?,?,?,?,?) '''
        cur = conn.cursor()
        task_1 = (5, locationData, reservationDateData, reservationTypeData, reservationStartTimeData, reservationEndTimeData)
        cur.execute(sql, task_1)
        conn.commit()
    return render(request, "index.html")

    